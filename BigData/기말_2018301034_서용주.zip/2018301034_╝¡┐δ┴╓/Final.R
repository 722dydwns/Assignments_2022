.libPaths()
.libPaths("C:/Program Files/R/R-4.1.3/library")

#1번
data1 <- read.csv("c:/test/Server.csv")

data11 <- data.frame(data1)

sapply(data11, class)

aovResult <- aov(data = data11)
TukeyHSD(aovResult)

#2번

data2 <- read.csv("c:/test/NASCAR.csv")

data2

#다중공산성 함수를 위한 패키지 등록 
require(car)

vif(lm(data2$Winnings ~ data2$Points+data2$Poles+data2$Wins+data2$Top.5+data2$Top.10, data = data2))

#3번  로지스틱 회귀분석
#데이터
data3 <- read.csv("c:/test/Stroke.csv")
data3
#로지스틱 회귀모형 R 코드
result3 <- glm(data3$위험.확률 ~ data3$나이+data3$혈압+data3$흡연여부)
summary(result3)

#계수의 신뢰구간 
confint(result3)

#로지스틱 예측 
predict(result3)

# 4번 문제

data4 <- read.csv("c:/test/Stroke.csv")
data4

#흡연여부에 대한 판별 분석 실시 

# (1) 흡연여부에 따른 위험확률 판별 분석 
result1 <- lm(data4$위험.확률 ~ data4$흡연여부)
summary(result1)

# (2) 흡연여부에 따른 나이 판별 분석
result2 <- lm(data4$나이~ data4$흡연여부)
summary(result2)

# (3) 흡연여부에 따른 혈압 판별 분석
result3 <- lm(data4$혈압 ~ data4$흡연여부)
summary(result3)


#5번 문제
data5 <- UKDriverDeaths
data5

#ets() 확인하여 비교분석 

ets1 <- ets(data5, model="AAA")

#추정값
fitted(ets1)

#잔차
residuals(ets1)

#정확성 척도
accuracy(ets1)

#예측값
forecast(ets1)

#요약
summary(ets1)

#그래프
plot(ets1)

#6개 구간 예측
Holt5 <- HoltWinters(data5, gamma=FALSE)

Holt5_pred <- predict(Holt5, 6, prediction.interval = TRUE)

plot(Holt5, Holt5_pred, ,ao"Including Predictaed Values", ylap = "")






